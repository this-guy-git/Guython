import sys
import os

from core.interpreter import GuythonInterpreter
from core.constants import VERSION


def main():
    interpreter = GuythonInterpreter()

if __name__ == '__main__':
    main()
