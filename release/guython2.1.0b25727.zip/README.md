### **GUYTHON V2.1.0B25727**

Guython is a ***VERY*** simple programming language created with Python.

**PLEASE** read 'grammar.txt' as it contains all syntax on the current version of Guython.

This is the Github version, you can check out VSCode extension [here](https://github.com/this-guy-git/guython-vscode), or downlaod [here](https://marketplace.visualstudio.com/items?itemName=tgl.guython).

### **Installation**
Installing Guython is very easy!
- Install the 'guython{ver}.zip' file.
- Unzip the file.
- Run the 'guython.py' file.
OR install the Guython VSCode Extension.

### **Running external files**
Run an external file by placing your '.guy' or '.gy' file in the same directory as the 'guython.py' file, and then use the command 'guython {fileName}.gy/.guy' in the intepreter.
OR run 'python guython.py {fileName}.gy/.guy' in the cmd prompt or terminal while in the same directory as the 'guython.py' file, for debug mode run 'python guython.py --debug {fileName}.gy/.guy'

### **Requirements**
Requires Pillow, which you can install with 'pip install pillow'.
Better to run the interpreter in Command Prompt because VSCode cannot import Pillow for some reason.

### **Whats New for Guython**
- Added 'exit_' command that can be used in files
- Added function arguments like defname_ arg1, arg2, arg3...

### **Whats New for Multi-tool**

### **Whats New for GPD**
- Added a forgotten comma that broke the ENTIRE package system
